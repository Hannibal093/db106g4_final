from pymongo import MongoClient
import pandas as pd


class MongoConnection(object):

    def __init__(self):
        self.client = MongoClient('mongodb://hannibal:`1q@192.168.1.109:27017/news')

    def get_database(self, dbname):
        self.db = self.client[dbname]

    def get_collection(self, name):
        self.collection = self.db[name]


class NewsCollection(MongoConnection):

    def __init__(self):
        super(NewsCollection, self).__init__()
        self.get_database('news')
        self.get_collection('news.doc')

    def find_twenty(self, page):
        news_list = []

        if page >= 1:
            page -= 1
        else:
            page = 0
        if self.collection.find({}).count():
            for i in self.collection.find().skip(page*20).limit(20).sort('time',-1):
                news_list.append(i)
        return news_list

    def find_all(self):
        return self.collection.find({})

    def find_all_list(self):
        news_list = []
        news_data = self.collection.find({})
        for n in news_data:
            news_list.append(n)
        return news_list

    def find_single(self):
        return self.collection.find_one({})

    def find_by_source(self, source):
        news_list = []
        for i in self.collection.find({"source": source}):
            news_list.append(i)
        return news_list

    def find_collections(self):
        return self.db.list_collection_names()

    def count_doc(self):
        return self.collection.count_doc()

    def category_update(self, title, new_list):
        self.collection.find_one({"title": title}, {"$set": {"category": new_list}})

    # def update_and_save(self, obj):
    #    if self.collection.find({'id': obj.id}).count():
    #        self.collection.update({ "id": obj.id},{'id':123,'name':'test'})
    #    else:
    #        self.collection.insert_one({'id':123,'name':'test'})
    #
    # def remove(self, obj):
    #     if self.collection.find({'id': obj.id}).count():
    #        self.collection.delete_one({ "id": obj.id})


class StockCollection(MongoConnection):

    def __init__(self):
        super(StockCollection, self).__init__()
        self.get_database('stock')
        self.get_collection('stock.doc')

    def get_stock_list(self):
        stock_list = []
        stock_data = self.collection.find({}, {"_id": 0, "stock_id": 1, "stock_name": 1}).sort("stock_id", 1)
        for i in stock_data:
            stock_list.append(i)
        return stock_list

    def get_stock_list_ftn(self, page):
        stock_list = []

        if page >= 1:
            page -= 1
        else:
            page = 0

        stock_data = self.collection.find({"industry":{"$exists":True}}, {"_id": 0,
                                                                            "stock_id": 1,
                                                                            "stock_name": 1,
                                                                            "industry":1}).sort("stock_id", 1).skip(page*15).limit(15)
        for i in stock_data:
            stock_list.append(i)
        return stock_list

    def get_single_by_id(self, stock_id='2330'):
        stock_data = self.collection.find_one({"stock_id": stock_id})
        return stock_data

    def get_by_name(self, stock_name='台積電'):
        stock_data = self.collection.find_one({"stock_name": stock_name})

        return stock_data

    def get_single_price(self, stock_id):
        stock_data = self.collection.find_one({"stock_id":stock_id},{"_id":0,"price":1})
        df = pd.DataFrame(stock_data['price']).set_index('date')
        return df
